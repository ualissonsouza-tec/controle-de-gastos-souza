# Sistema de Controle de Gastos para Obras

Um sistema web moderno e responsivo para gerenciar gastos de construção de forma eficiente.

## 🚀 Funcionalidades

### 📊 Dashboard
- **Total Gasto**: Soma de todos os gastos registrados
- **Orçamento**: Valor total do orçamento definido
- **Saldo**: Diferença entre orçamento e gastos totais

### ➕ Gestão de Gastos
- Adicionar novos gastos com informações detalhadas
- Categorização automática (Material, Mão de Obra, Equipamento, etc.)
- Registro de fornecedor e observações
- Data automática do gasto

### 📋 Listagem e Filtros
- Visualização de todos os gastos registrados
- Filtro por categoria
- Filtro por mês/ano
- Ordenação por data (mais recentes primeiro)

### 💰 Controle de Orçamento
- Definição de orçamento total
- Acompanhamento em tempo real do saldo
- Alertas visuais quando o orçamento é excedido

### 📤 Exportação de Dados
- Exportação para CSV
- Geração de relatório PDF
- Backup automático no navegador

## 🛠️ Tecnologias Utilizadas

- **HTML5**: Estrutura semântica
- **CSS3**: Design moderno e responsivo
- **JavaScript**: Funcionalidades dinâmicas
- **LocalStorage**: Armazenamento local dos dados
- **Font Awesome**: Ícones modernos

## 📱 Responsividade

O sistema é totalmente responsivo e funciona perfeitamente em:
- Desktop
- Tablet
- Smartphone

## 🎨 Design

- Interface moderna com gradientes
- Animações suaves
- Cores intuitivas (verde para positivo, vermelho para negativo)
- Ícones informativos
- Cards com efeito hover

## 📁 Estrutura de Arquivos

```
├── index.html          # Página principal
├── styles.css          # Estilos CSS
├── script.js           # Funcionalidades JavaScript
└── README.md           # Documentação
```

## 🚀 Como Usar

1. **Abra o arquivo `index.html`** em qualquer navegador moderno
2. **Configure o orçamento** na seção "Configurar Orçamento"
3. **Adicione gastos** usando o formulário "Adicionar Gasto"
4. **Visualize e filtre** os gastos na lista
5. **Exporte relatórios** quando necessário

## 📊 Categorias de Gastos

- **Material**: Cimento, tijolos, aço, etc.
- **Mão de Obra**: Pagamentos a funcionários
- **Equipamento**: Aluguel de máquinas, ferramentas
- **Serviço Terceirizado**: Contratação de empresas
- **Administrativo**: Documentação, licenças
- **Outros**: Gastos diversos

## 💾 Armazenamento

Os dados são salvos automaticamente no navegador usando LocalStorage:
- Gastos registrados
- Orçamento definido
- Configurações de filtros

## 🔧 Personalização

### Cores
As cores podem ser alteradas no arquivo `styles.css`:
- Gradiente principal: `#667eea` para `#764ba2`
- Verde (sucesso): `#27ae60`
- Vermelho (erro): `#e74c3c`
- Azul (informação): `#3498db`

### Categorias
Para adicionar novas categorias, edite:
1. `index.html` - opções do select
2. `script.js` - função `getCategoryLabel()`

## 📈 Recursos Avançados

### Notificações
- Feedback visual para todas as ações
- Notificações temporárias
- Cores baseadas no tipo de ação

### Animações
- Transições suaves
- Efeitos hover
- Animações de entrada para novos itens

### Filtros Inteligentes
- Filtro por categoria
- Filtro por período
- Combinação de filtros

## 🔒 Segurança

- Validação de dados no frontend
- Sanitização de inputs
- Confirmação para exclusões

## 📱 Compatibilidade

- Chrome 60+
- Firefox 55+
- Safari 12+
- Edge 79+

## 🚀 Próximas Funcionalidades

- [ ] Gráficos e estatísticas
- [ ] Backup na nuvem
- [ ] Múltiplas obras
- [ ] Relatórios avançados
- [ ] Integração com APIs
- [ ] Modo offline

## 🤝 Contribuição

Para contribuir com o projeto:
1. Faça um fork do repositório
2. Crie uma branch para sua feature
3. Commit suas mudanças
4. Push para a branch
5. Abra um Pull Request

## 📄 Licença

Este projeto está sob a licença MIT. Veja o arquivo LICENSE para mais detalhes.

## 📞 Suporte

Para dúvidas ou sugestões:
- Abra uma issue no repositório
- Entre em contato via email

---

**Desenvolvido com ❤️ para facilitar o controle de gastos em obras** 