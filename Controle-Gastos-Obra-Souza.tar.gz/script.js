/* ===== VARIÁVEIS GLOBAIS E DADOS DA APLICAÇÃO ===== */
let expenses = JSON.parse(localStorage.getItem('expenses')) || [];
let budget = parseFloat(localStorage.getItem('budget')) || 0;

/* ===== ELEMENTOS DO DOM - FORMULÁRIOS E CONTROLES ===== */
const expenseForm = document.getElementById('expenseForm');
const budgetForm = document.getElementById('budgetForm');
const expensesList = document.getElementById('expensesList');
const categoryFilter = document.getElementById('categoryFilter');
const monthFilter = document.getElementById('monthFilter');

/* ===== ELEMENTOS DO DOM - CONTROLES DE TEMA E USUÁRIO ===== */
const themeToggle = document.getElementById('themeToggle');
const themeIcon = themeToggle.querySelector('i');
const userModal = document.getElementById('userModal');
const userForm = document.getElementById('userForm');
const userNameInput = document.getElementById('userName');
const userCPFInput = document.getElementById('userCPF');
const logoutButton = document.getElementById('logoutButton');

/* ===== FUNÇÕES DE GERENCIAMENTO DE USUÁRIO ===== */

/**
 * Gera uma chave única para armazenar dados do usuário no localStorage
 * @returns {string} Chave formatada para o usuário atual
 */
function getUserKey() {
    const user = JSON.parse(localStorage.getItem('currentUser'));
    return user ? `expenses_${user.cpf}` : 'expenses';
}

/**
 * Exibe o modal de identificação do usuário
 */
function showUserModal() {
    userModal.style.display = 'flex';
}

/**
 * Oculta o modal de identificação do usuário
 */
function hideUserModal() {
    userModal.style.display = 'none';
}

/**
 * Salva os dados do usuário atual no localStorage
 * @param {string} name - Nome do usuário
 * @param {string} cpf - CPF do usuário
 */
function saveCurrentUser(name, cpf) {
    localStorage.setItem('currentUser', JSON.stringify({ name, cpf }));
}

/**
 * Obtém os dados do usuário atual do localStorage
 * @returns {object|null} Dados do usuário ou null se não existir
 */
function getCurrentUser() {
    return JSON.parse(localStorage.getItem('currentUser'));
}

/**
 * Carrega os gastos específicos do usuário atual
 */
function loadUserExpenses() {
    const key = getUserKey();
    expenses = JSON.parse(localStorage.getItem(key)) || [];
}

/**
 * Salva os gastos do usuário atual no localStorage
 */
function saveUserExpenses() {
    const key = getUserKey();
    localStorage.setItem(key, JSON.stringify(expenses));
}

/* ===== EVENT LISTENER - FORMULÁRIO DE LOGIN ===== */
userForm.addEventListener('submit', function(e) {
    e.preventDefault();
    console.log('Formulário de login submetido');
    
    const name = userNameInput.value.trim();
    const cpf = userCPFInput.value.replace(/\D/g, '');
    
    console.log('Nome:', name);
    console.log('CPF:', cpf);
    
    // Validação do nome
    if (name.length < 3) {
        showNotification('Nome deve ter pelo menos 3 caracteres.', 'error');
        return;
    }
    
    // Validação do CPF
    if (cpf.length !== 11) {
        showNotification('CPF deve ter 11 dígitos.', 'error');
        return;
    }
    
    console.log('Dados válidos, salvando usuário...');
    saveCurrentUser(name, cpf);
    hideUserModal();
    loadUserExpenses();
    updateDashboard();
    renderExpenses();
    
    showNotification(`Bem-vindo, ${name}!`, 'success');
});

/* ===== FUNÇÕES DE INICIALIZAÇÃO ===== */

/**
 * Inicializa a aplicação quando o DOM é carregado
 */
document.addEventListener('DOMContentLoaded', function() {
    // Verificar se há usuário logado
    const currentUser = getCurrentUser();
    if (!currentUser) {
        showUserModal();
    } else {
        hideUserModal();
        loadUserExpenses();
    }
    
    updateDashboard();
    renderExpenses();
    setCurrentDate();
    
    // Event listeners para formulários e filtros
    expenseForm.addEventListener('submit', addExpense);
    budgetForm.addEventListener('submit', setBudget);
    categoryFilter.addEventListener('change', filterExpenses);
    monthFilter.addEventListener('change', filterExpenses);
    
    // Carregar tema salvo
    const savedTheme = localStorage.getItem('theme');
    setTheme(savedTheme === 'dark');
});

/* ===== FUNÇÕES DE UTILIDADE ===== */

/**
 * Define a data atual no campo de data
 */
function setCurrentDate() {
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('date').value = today;
}

/**
 * Formata valor monetário para o padrão brasileiro
 * @param {number} amount - Valor a ser formatado
 * @returns {string} Valor formatado em reais
 */
function formatCurrency(amount) {
    return new Intl.NumberFormat('pt-BR', {
        style: 'currency',
        currency: 'BRL'
    }).format(amount);
}

/**
 * Formata data para o padrão brasileiro
 * @param {string} dateString - Data em formato string
 * @returns {string} Data formatada
 */
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR');
}

/**
 * Obtém o label da categoria baseado no valor
 * @param {string} category - Valor da categoria
 * @returns {string} Label da categoria
 */
function getCategoryLabel(category) {
    const labels = {
        'material': 'Material',
        'mao-de-obra': 'Mão de Obra',
        'equipamento': 'Equipamento',
        'servico': 'Serviço Terceirizado',
        'administrativo': 'Administrativo',
        'outros': 'Outros'
    };
    return labels[category] || category;
}

/* ===== FUNÇÕES DE GERENCIAMENTO DE GASTOS ===== */

/**
 * Adiciona um novo gasto ao sistema
 * @param {Event} e - Evento do formulário
 */
function addExpense(e) {
    e.preventDefault();
    
    const expense = {
        id: Date.now(),
        description: document.getElementById('description').value,
        category: document.getElementById('category').value,
        amount: parseFloat(document.getElementById('amount').value),
        date: document.getElementById('date').value,
        supplier: document.getElementById('supplier').value,
        notes: document.getElementById('notes').value,
        createdAt: new Date().toISOString()
    };
    
    expenses.push(expense);
    saveExpenses();
    updateDashboard();
    renderExpenses();
    
    // Limpar formulário
    expenseForm.reset();
    setCurrentDate();
    
    // Feedback visual
    showNotification('Gasto adicionado com sucesso!', 'success');
}

/**
 * Define o orçamento total do projeto
 * @param {Event} e - Evento do formulário
 */
function setBudget(e) {
    e.preventDefault();
    
    const newBudget = parseFloat(document.getElementById('totalBudget').value);
    if (newBudget >= 0) {
        budget = newBudget;
        localStorage.setItem('budget', budget.toString());
        updateDashboard();
        showNotification('Orçamento atualizado com sucesso!', 'success');
    } else {
        showNotification('Por favor, insira um valor válido.', 'error');
    }
}

/**
 * Remove um gasto do sistema
 * @param {number} id - ID do gasto a ser removido
 */
function deleteExpense(id) {
    if (confirm('Tem certeza que deseja excluir este gasto?')) {
        expenses = expenses.filter(expense => expense.id !== id);
        saveExpenses();
        updateDashboard();
        renderExpenses();
        showNotification('Gasto excluído com sucesso!', 'success');
    }
}

/**
 * Salva os gastos no localStorage (wrapper para saveUserExpenses)
 */
function saveExpenses() { 
    saveUserExpenses(); 
}

/* ===== FUNÇÕES DE ATUALIZAÇÃO DA INTERFACE ===== */

/**
 * Atualiza o dashboard com os valores calculados
 */
function updateDashboard() {
    const totalAmount = expenses.reduce((sum, expense) => sum + expense.amount, 0);
    const balance = budget - totalAmount;
    
    document.getElementById('totalAmount').textContent = formatCurrency(totalAmount);
    document.getElementById('budgetAmount').textContent = formatCurrency(budget);
    document.getElementById('balanceAmount').textContent = formatCurrency(balance);
    
    // Atualizar cores baseado no saldo
    const balanceElement = document.getElementById('balanceAmount');
    if (balance < 0) {
        balanceElement.style.color = '#e74c3c';
    } else if (balance > 0) {
        balanceElement.style.color = '#27ae60';
    } else {
        balanceElement.style.color = '#3498db';
    }
}

/**
 * Renderiza a lista de gastos na interface
 */
function renderExpenses() {
    const filteredExpenses = getFilteredExpenses();
    
    if (filteredExpenses.length === 0) {
        expensesList.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-receipt"></i>
                <h3>Nenhum gasto encontrado</h3>
                <p>Adicione seu primeiro gasto usando o formulário ao lado.</p>
            </div>
        `;
        return;
    }
    
    expensesList.innerHTML = filteredExpenses.map(expense => `
        <div class="expense-item">
            <div class="expense-header">
                <div>
                    <div class="expense-category">${getCategoryLabel(expense.category)}</div>
                    <div class="expense-title">${expense.description}</div>
                </div>
                <div>
                    <div class="expense-amount">${formatCurrency(expense.amount)}</div>
                    <button class="delete-btn" onclick="deleteExpense(${expense.id})">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
            <div class="expense-details">
                <div><strong>Data:</strong> ${formatDate(expense.date)}</div>
                ${expense.supplier ? `<div><strong>Fornecedor:</strong> ${expense.supplier}</div>` : ''}
                ${expense.notes ? `<div><strong>Observações:</strong> ${expense.notes}</div>` : ''}
            </div>
        </div>
    `).join('');
}

/* ===== FUNÇÕES DE FILTRAGEM ===== */

/**
 * Obtém a lista de gastos filtrada conforme os filtros aplicados
 * @returns {Array} Lista de gastos filtrada
 */
function getFilteredExpenses() {
    let filtered = [...expenses];
    
    const categoryFilterValue = categoryFilter.value;
    const monthFilterValue = monthFilter.value;
    
    if (categoryFilterValue) {
        filtered = filtered.filter(expense => expense.category === categoryFilterValue);
    }
    
    if (monthFilterValue) {
        filtered = filtered.filter(expense => expense.date.startsWith(monthFilterValue));
    }
    
    return filtered.sort((a, b) => new Date(b.date) - new Date(a.date));
}

/**
 * Aplica os filtros e atualiza a lista de gastos
 */
function filterExpenses() {
    renderExpenses();
}

/* ===== FUNÇÕES DE NOTIFICAÇÃO ===== */

/**
 * Exibe uma notificação na tela
 * @param {string} message - Mensagem a ser exibida
 * @param {string} type - Tipo da notificação (success, error, info)
 */
function showNotification(message, type = 'info') {
    // Criar elemento de notificação
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'}"></i>
        <span>${message}</span>
    `;
    
    // Adicionar estilos
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: ${type === 'success' ? '#27ae60' : type === 'error' ? '#e74c3c' : '#3498db'};
        color: white;
        padding: 15px 20px;
        border-radius: 8px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        z-index: 1000;
        display: flex;
        align-items: center;
        gap: 10px;
        animation: slideInRight 0.3s ease;
    `;
    
    document.body.appendChild(notification);
    
    // Remover após 3 segundos
    setTimeout(() => {
        notification.style.animation = 'slideOutRight 0.3s ease';
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}

/* ===== FUNÇÕES DE EXPORTAÇÃO ===== */

/**
 * Exporta os dados para formato CSV
 */
function exportToCSV() {
    const headers = ['Descrição', 'Categoria', 'Valor', 'Data', 'Fornecedor', 'Observações'];
    const csvContent = [
        headers.join(','),
        ...expenses.map(expense => [
            `"${expense.description}"`,
            `"${getCategoryLabel(expense.category)}"`,
            expense.amount,
            expense.date,
            `"${expense.supplier || ''}"`,
            `"${expense.notes || ''}"`
        ].join(','))
    ].join('\n');
    
    downloadFile(csvContent, 'gastos-obra.csv', 'text/csv');
    showNotification('Arquivo CSV exportado com sucesso!', 'success');
}

/**
 * Exporta os dados para formato PDF
 */
function exportToPDF() {
    // Criar conteúdo HTML para PDF
    const content = `
        <html>
        <head>
            <title>Relatório de Gastos - Obra</title>
            <style>
                body { font-family: Arial, sans-serif; margin: 20px; }
                table { width: 100%; border-collapse: collapse; margin-top: 20px; }
                th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
                th { background-color: #f2f2f2; }
                .header { text-align: center; margin-bottom: 30px; }
                .summary { margin: 20px 0; }
            </style>
        </head>
        <body>
            <div class="header">
                <h1>Relatório de Gastos - Obra</h1>
                <p>Data: ${new Date().toLocaleDateString('pt-BR')}</p>
            </div>
            
            <div class="summary">
                <h3>Resumo</h3>
                <p><strong>Total Gasto:</strong> ${formatCurrency(expenses.reduce((sum, exp) => sum + exp.amount, 0))}</p>
                <p><strong>Orçamento:</strong> ${formatCurrency(budget)}</p>
                <p><strong>Saldo:</strong> ${formatCurrency(budget - expenses.reduce((sum, exp) => sum + exp.amount, 0))}</p>
            </div>
            
            <table>
                <thead>
                    <tr>
                        <th>Descrição</th>
                        <th>Categoria</th>
                        <th>Valor</th>
                        <th>Data</th>
                        <th>Fornecedor</th>
                    </tr>
                </thead>
                <tbody>
                    ${expenses.map(expense => `
                        <tr>
                            <td>${expense.description}</td>
                            <td>${getCategoryLabel(expense.category)}</td>
                            <td>${formatCurrency(expense.amount)}</td>
                            <td>${formatDate(expense.date)}</td>
                            <td>${expense.supplier || '-'}</td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        </body>
        </html>
    `;
    
    // Usar jsPDF se disponível, senão mostrar mensagem
    if (typeof window.jsPDF !== 'undefined') {
        const { jsPDF } = window.jsPDF;
        const doc = new jsPDF();
        
        // Adicionar conteúdo ao PDF
        doc.html(content, {
            callback: function(doc) {
                doc.save('relatorio-gastos-obra.pdf');
            }
        });
    } else {
        // Fallback: abrir em nova janela para impressão
        const newWindow = window.open('', '_blank');
        newWindow.document.write(content);
        newWindow.document.close();
        newWindow.print();
    }
    
    showNotification('Relatório PDF gerado com sucesso!', 'success');
}

/**
 * Faz o download de um arquivo
 * @param {string} content - Conteúdo do arquivo
 * @param {string} filename - Nome do arquivo
 * @param {string} contentType - Tipo do conteúdo
 */
function downloadFile(content, filename, contentType) {
    const blob = new Blob([content], { type: contentType });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
}

/* ===== FUNÇÕES DE TEMA (CLARO/ESCURO) ===== */

/**
 * Define o tema da aplicação (claro ou escuro)
 * @param {boolean} dark - true para modo escuro, false para modo claro
 */
function setTheme(dark) {
    if (dark) {
        document.body.classList.add('dark-mode');
        themeIcon.classList.remove('fa-moon');
        themeIcon.classList.add('fa-sun');
        themeToggle.title = 'Modo claro';
        localStorage.setItem('theme', 'dark');
    } else {
        document.body.classList.remove('dark-mode');
        themeIcon.classList.remove('fa-sun');
        themeIcon.classList.add('fa-moon');
        themeToggle.title = 'Modo escuro';
        localStorage.setItem('theme', 'light');
    }
}

/* ===== EVENT LISTENERS PARA CONTROLES ===== */

// Event listener para alternância de tema
themeToggle.addEventListener('click', () => {
    const isDark = document.body.classList.contains('dark-mode');
    setTheme(!isDark);
});

// Event listener para logout
logoutButton.addEventListener('click', function() {
    if (confirm('Tem certeza que deseja sair? Todos os dados não salvos serão perdidos.')) {
        // Limpar dados do usuário atual
        localStorage.removeItem('currentUser');
        localStorage.removeItem('budget');
        
        // Limpar formulários
        expenseForm.reset();
        budgetForm.reset();
        
        // Limpar arrays
        expenses = [];
        
        // Mostrar modal de login novamente
        showUserModal();
        
        // Limpar dashboard
        updateDashboard();
        renderExpenses();
        
        showNotification('Logout realizado com sucesso!', 'success');
    }
});

/* ===== ESTILOS CSS DINÂMICOS ===== */

// Adicionar estilos CSS para animações de notificação
const style = document.createElement('style');
style.textContent = `
    @keyframes slideInRight {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOutRight {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);

/* ===== INICIALIZAÇÃO FINAL ===== */

// Carregar orçamento salvo
if (budget > 0) {
    document.getElementById('totalBudget').value = budget;
} 